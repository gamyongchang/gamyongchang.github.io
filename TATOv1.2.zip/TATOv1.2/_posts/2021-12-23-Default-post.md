---
layout: post
title: Default post
category: Default
---
This is just a default post to test whether _posts can work correctly.